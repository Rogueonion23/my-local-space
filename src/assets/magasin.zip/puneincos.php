<?
/* ca sa avem acces la variabilele de sesiune dam session_start*/
session_start();  
/* luam codul produsului trimis de forma din cumpara.php */
$codprod=$_GET['codprod'];  ?>
<html>
<head>
   <title>Magazinul Chez Nous</title>
</head>
<body>
   <h1>Felicitari!</h1>
   Ati ales un produs deosebit!
   <hr>
   <?
   $cerere="select codp, nume, pret from produse where codp = '$codprod'";
   ($conn = mysqli_connect("localhost", "root", "")) or 
      die("Conexiune esuata:".mysqli_error($conn)."<br>\n");
   mysqli_select_db($conn, "prj") 
      or die("Selectare baza date esuata:".mysqli_error($conn)."<br>\n");
   // executie:
   ($rezultat=mysqli_query($conn, $cerere)) 
      or die("Cerere SQL esuata: ".mysqli_error($conn)."<br>\n");
   while ($linie=mysqli_fetch_row($rezultat))
     {
     $_SESSION["nrprod"]++;
     $_SESSION["cp"][] = $linie[0];
     $_SESSION["np"][] = $linie[1];
     $_SESSION["pp"][] = $linie[2];
     $_SESSION["total"] = $_SESSION["total"] + $linie[2];
     }
   echo "Ati cumparat pana acum ".$_SESSION["nrprod"].
        " produse la un pret total de ".$_SESSION["total"]." lei<br>\n";
   for ($i=0;$i<$_SESSION["nrprod"];$i++)
     echo $_SESSION["np"][$i]." pret: ".$_SESSION["pp"][$i]."<br>\n";
?>
   <hr>
   &copy; Copyright 2021 Florin Radulescu
</body>
</html>
