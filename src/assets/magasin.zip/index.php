<? 
session_start();
if (!isset($_SESSION["intrat"]))
/* urmeaza initializarile executate la prima intrare pe aceasta pagina */
{  $_SESSION["intrat"] = 1;
   $_SESSION["nrprod"] = 0;
   $_SESSION["total"] = 0;
   $_SESSION["cp"] = array();
   $_SESSION["np"] = array();
   $_SESSION["pp"] = array();
}
?>
<html>
<head>
   <title>Magazinul Chez Nous</title>
</head>
<body>
   <h1>Bine ati venit la magazinul Chez Nous!</h1>
   Avem un sortiment bogat de produse de urmatoarele tipuri. Selectati unul
   dintre ele si apoi apasati butonul <b>[Vezi si cumpara]</b>.
   <hr>
   Sortimente in stoc:<br>
   <?
   $cerere="select distinct tip from produse";
   ($conn = mysqli_connect("localhost", "root", "")) or 
      die("Conexiune esuata:".mysqli_error($conn)."<br>\n");
   mysqli_select_db($conn, "prj1") 
      or die("Selectare baza date esuata:".mysqli_error($conn)."<br>\n");
   // executie:
   ($rezultat=mysqli_query($conn, $cerere)) 
      or die("Cerere SQL esuata: ".mysqli_error($conn)."<br>\n");
   ?>
   <form action="cumpara.php" method=get>
   <table>
   <?
   while ($linie=mysqli_fetch_row($rezultat))
     {
     echo "<tr><td>\n";
     echo "<input type=radio name=tipprod value=$linie[0]>$linie[0]<br></td></tr>\n";
     }
   ?>
   <tr><td>
   <input type=submit value="[Vezi si cumpara]">
   </tr></td>
   </table>
   </form>
   <hr>
   Multumim ca ati cumparat de la noi. Mai poftiti si altadata.<p>
   &copy; Copyright 2021 Florin Radulescu
</body>
</html>
