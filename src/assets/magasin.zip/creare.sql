-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2021 at 10:03 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prj`
--

-- --------------------------------------------------------

--
-- Table structure for table `produse`
--

CREATE TABLE `produse` (
  `codp` int(4) NOT NULL,
  `nume` varchar(20) DEFAULT NULL,
  `pret` int(8) DEFAULT NULL,
  `tip` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produse`
--

INSERT INTO `produse` (`codp`, `nume`, `pret`, `tip`) VALUES
(1, 'PANTOFI DE DAMA', 500, 'INCALTAMINTE'),
(2, 'PANTOFI BARBATI', 400, 'INCALTAMINTE'),
(3, 'PANTOFI DE LAC', 600, 'INCALTAMINTE'),
(4, 'BOCANCI SKI', 800, 'INCALTAMINTE'),
(5, 'CARNE VITA', 90, 'CARNE'),
(6, 'CARNE PORC', 90, 'CARNE'),
(7, 'CARNE MICI', 60, 'CARNE'),
(8, 'CARNE MIEL', 90, 'CARNE'),
(9, 'ASPIRATOR PHILIPS', 900, 'ELECTRICE'),
(10, 'ASPIRATOR SAMSUNG', 1900, 'ELECTRICE'),
(11, 'TV PHILIPS', 6900, 'ELECTRICE'),
(12, 'RC TOSHIBA', 1900, 'ELECTRICE'),
(13, 'BECURI ECONOMICE', 90, 'ELECTRICE'),
(14, 'DEUX PIECES', 1900, 'IMBRACAMINTE'),
(15, 'DEUX PIECES', 2900, 'IMBRACAMINTE'),
(16, 'COSTUM BARBATI', 3900, 'IMBRACAMINTE'),
(17, 'COSTUM DAMA', 4900, 'IMBRACAMINTE'),
(18, 'ROCHIE DE MIREASA', 5900, 'IMBRACAMINTE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `produse`
--
ALTER TABLE `produse`
  ADD PRIMARY KEY (`codp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `produse`
--
ALTER TABLE `produse`
  MODIFY `codp` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
