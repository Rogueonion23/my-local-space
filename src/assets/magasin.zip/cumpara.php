<?
$tipprod=$_GET['tipprod']; ?>
<html>
<head>
   <title>Magazinul Chez Nous</title>
</head>
<body>
   <h1>Bine ati venit la raionul de produse <? echo $tipprod; ?></h1>
   Avem un sortiment bogat de produse de tip <? echo $tipprod; ?>. Selectati unul
   dintre ele si apoi apasati butonul <b>[Pune in cosul de produse]</b>.
   <hr>
   Produse de tip <? echo $tipprod ?> in stoc:<br>
   <?
   $cerere="select codp, nume, pret from produse where tip = '$tipprod'";
   ($conn = mysqli_connect("localhost", "root", "")) or 
      die("Conexiune esuata:".mysqli_error($conn)."<br>\n");
   mysqli_select_db($conn, "prj") 
      or die("Selectare baza date esuata:".mysqli_error($conn)."<br>\n");
   // executie:
   ($rezultat=mysqli_query($conn, $cerere)) 
      or die("Cerere SQL esuata: ".mysql_error($conn)."<br>\n");
   ?>
   <form action="puneincos.php" method=get>
   <?
   while ($linie=mysqli_fetch_row($rezultat))
     echo "<input type=radio name=codprod value=$linie[0]>$linie[1] pret:$linie[2].<br>\n";
   ?>
   <input type=submit value="[Pune in cosul de produse]">
   </form>
   <hr>
   &copy; Copyright 2021 Florin Radulescu
   </body>
   </html>
